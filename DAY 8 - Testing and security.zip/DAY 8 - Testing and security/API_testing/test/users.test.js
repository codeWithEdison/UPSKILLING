import { expect } from 'chai';
import dbconn from '../db_connection.js';
import app from '../app.js';
import request from 'supertest';

before((done) => {
  dbconn.connect(done);
});

after((done) => {
  dbconn.end(done);
});

describe('USER API', () => {
  it('should create new user', (done) => {
    request(app)
      .post('/api/createUser')
      .send({ username: 'test_username', password: 'test_password' })
      .expect(201)
      .end((err, res) => {
        if (err) return done(err);
        expect(res.text).to.equal('User created successfully');
        done();
      });
  });
});
